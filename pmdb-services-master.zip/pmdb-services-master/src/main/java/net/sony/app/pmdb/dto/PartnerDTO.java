package net.sony.app.pmdb.dto;

import java.io.Serializable;

public class PartnerDTO implements Serializable{

	private String partnerName;
	private String displayName;
	private Integer partyLevel;
	private String partnerCategoryCode;
	private String partnerStatusCode;
	private PartyDTO partyDTO;

	
	
}
